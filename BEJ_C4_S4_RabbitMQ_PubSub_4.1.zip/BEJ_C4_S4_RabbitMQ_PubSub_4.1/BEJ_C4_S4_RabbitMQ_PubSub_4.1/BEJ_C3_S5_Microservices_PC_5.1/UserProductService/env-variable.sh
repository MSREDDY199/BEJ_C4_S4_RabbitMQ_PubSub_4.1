export MONGO_DATABASE=mydb
export MONGO_URI=mongodb://localhost:27017/mydb